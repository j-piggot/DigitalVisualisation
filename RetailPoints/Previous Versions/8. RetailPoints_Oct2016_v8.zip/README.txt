This file contains:

DATA:
GeoLytixRetailPoints[Date][Version].zip contains the data in .txt and .xls format --- This is the latest data, the date and version changes to the update of each release

DOCUMENTATION:
GeoLytix_RetailPoints_VersionsControl.xlsx --- This tracks the changes through the versions
GeoLytix_RetailPoints_DataDefinitions.pdf --- Meta data

LICENSE:
GeoLytix_RetailPoints_OpenDataLicense.pdf --- Data license


WEBSITE

For more information and the latest downloads visit http://www.geolytix.co.uk

CONTACT

If you have any questions about this data please contact GeoLytix at info@geolytix.co.uk

