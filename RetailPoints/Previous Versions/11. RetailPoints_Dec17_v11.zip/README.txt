This file contains:

DATA:
GeolytixRetailPoints[Date][Version].zip contains the data in .txt and .xls format --- This is the latest data, the date and version changes to the update of each release

DOCUMENTATION:
Geolytix RetailPoints VersionControl.xlsx --- This tracks the changes through the versions
Geolytix RetailPoints DataDefinitions.pdf --- Meta data

LICENSE:
Geolytix RetailPoints OpenDataLicense.pdf --- Data license


WEBSITE

For more information and the latest downloads visit http://www.geolytix.co.uk

CONTACT

If you have any questions about this data please contact Geolytix at louise.cross@geolytix.co.uk

